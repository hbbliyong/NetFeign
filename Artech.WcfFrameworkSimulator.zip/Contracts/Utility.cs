﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.Text;
using System.Xml;

namespace Artech.WcfFrameworkSimulator.Contracts
{
    public static class Utility
    {
        private const string defaultNamespace = "http://tempuri.org/";

        public static void Create<T>(out MessageEncoderFactory encoderFactory,
            out IDictionary<string, IClientMessageFormatter> clientFormatters,
            out IDictionary<string, IDispatchMessageFormatter> dispatchFormatters,
            out IDictionary<string, IOperationInvoker> operationInvokers,
            out IDictionary<string, MethodInfo> methods)
        {
            //确保类型T是应用了ServiceContractAttribute的服务契约
            object[] attributes = typeof(T).GetCustomAttributes(typeof(ServiceContractAttribute), false);
            if (attributes.Length == 0)
            {
                throw new InvalidOperationException(string.Format("The type \"{0}\" is not a ServiceContract!", typeof(T).AssemblyQualifiedName));
            }

            //创建字典保存IClientMessageFormatter、IDispatchMessageFormatter、IOperationInvoker和MethodInfo
            clientFormatters = new Dictionary<string, IClientMessageFormatter>();
            dispatchFormatters = new Dictionary<string, IDispatchMessageFormatter>();
            operationInvokers = new Dictionary<string, IOperationInvoker>();
            methods = new Dictionary<string, MethodInfo>();

            //MessageEncoderFactory
            string encoderFactoryType = "System.ServiceModel.Channels.TextMessageEncoderFactory,System.ServiceModel, Version=3.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089";
            encoderFactory = (MessageEncoderFactory)Activator.CreateInstance(Type.GetType(encoderFactoryType), MessageVersion.Default, Encoding.UTF8, int.MaxValue, int.MaxValue, new XmlDictionaryReaderQuotas());

            //得到OperationDecription列表
            ServiceContractAttribute serviceAttribute = (ServiceContractAttribute)attributes[0];
            string serviceNamepace = string.IsNullOrEmpty(serviceAttribute.Namespace) ? defaultNamespace : serviceAttribute.Namespace;
            string serviceName = string.IsNullOrEmpty(serviceAttribute.Name) ? typeof(T).Name : serviceAttribute.Name;
            var operations = ContractDescription.GetContract(typeof(T)).Operations;

            //得到具体的IClientMessageFormatter、IDispatchMessageFormatter和IOperationInvoker的具体类型
            //IClientMessageFormatter+IDispatchMessageFormatter：DataContractSerializerOperationFormatter
            //IOperationInvoker：SyncMethodInvoker
            string formatterTypeName = "System.ServiceModel.Dispatcher.DataContractSerializerOperationFormatter,System.ServiceModel, Version=3.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089";
            Type formatterType = Type.GetType(formatterTypeName);
            ConstructorInfo formatterConstructor = formatterType.GetConstructor(new Type[] { typeof(OperationDescription), typeof(DataContractFormatAttribute), typeof(DataContractSerializerOperationBehavior) });
            string operationInvokerTypeName = "System.ServiceModel.Dispatcher.SyncMethodInvoker,System.ServiceModel, Version=3.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089";
            Type operationInvokerType = Type.GetType(operationInvokerTypeName);

            foreach (MethodInfo method in typeof(T).GetMethods())
            {
                attributes = method.GetCustomAttributes(typeof(OperationContractAttribute), true);
                if (attributes.Length > 0)
                {
                    OperationContractAttribute operationAttribute = (OperationContractAttribute)attributes[0];
                    string operationName = string.IsNullOrEmpty(operationAttribute.Name) ? method.Name : operationAttribute.Name;
                    //通过OperationContractAttribute得到Action
                    string action;
                    if (string.IsNullOrEmpty(operationAttribute.Action))
                    {
                        action = string.Format("{0}{1}/{2}", serviceNamepace, serviceName, operationName);
                    }
                    else
                    {
                        action = operationAttribute.Action;
                    }                    

                    OperationDescription operation = operations.Where(op => op.Name == operationName).ToArray<OperationDescription>()[0];
                    //通过反射创建DataContractSerializerOperationFormatter对象
                    object formatter = formatterConstructor.Invoke(new object[] { operation, new DataContractFormatAttribute(), null });
                    clientFormatters.Add(operationName, formatter as IClientMessageFormatter);
                    dispatchFormatters.Add(action, formatter as IDispatchMessageFormatter);
                   
                    //通过反射创建SyncMethodInvoker对象
                    IOperationInvoker operationInvoker = (IOperationInvoker)Activator.CreateInstance(operationInvokerType, method);
                    operationInvokers.Add(action, operationInvoker);
                    methods.Add(action, method);
                }
            }
        }
    }
}