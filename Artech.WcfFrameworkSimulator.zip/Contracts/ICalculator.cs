﻿using System.ServiceModel;
namespace Artech.WcfFrameworkSimulator.Contracts
{
    [ServiceContract(Namespace="http://www.artech.com/")]
    public interface ICalculator
    {
        [OperationContract]
        double Add(double x, double y);
    }
}
