﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;
using Artech.WcfFrameworkSimulator.Contracts;
namespace Artech.WcfFrameworkSimulator.Client
{
    public static class SerivceProxyFactory<T>
    {
        public static T Create(MessageVersion messageVersion,Uri remoteAddress)
        {
             MessageEncoderFactory encoderFactory;
             IDictionary<string, IClientMessageFormatter> clientFormatters;
             IDictionary<string, IDispatchMessageFormatter> dispatchFormatters;
             IDictionary<string, IOperationInvoker> operationInvokers;
             IDictionary<string, MethodInfo> methods;
             Utility.Create<T>(out encoderFactory,out clientFormatters,out dispatchFormatters,out operationInvokers,out methods);
             ServiceRealProxy<T> realProxy = new ServiceRealProxy<T>(messageVersion, remoteAddress, clientFormatters, encoderFactory);
             return (T) realProxy.GetTransparentProxy();
        }
    }
}