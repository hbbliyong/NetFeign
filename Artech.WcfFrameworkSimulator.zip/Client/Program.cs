﻿using System;
using System.ServiceModel.Channels;
using Artech.WcfFrameworkSimulator.Contracts;

namespace Artech.WcfFrameworkSimulator.Client
{
    class Program
    {
        static void Main(string[] args)
        {

            //ChannelFactory<ICalculator> channelFactory = new ChannelFactory<ICalculator>("calculateservice");
            //ICalculator calculator = channelFactory.CreateChannel();
            //double result = 7;
            //bool flag = calculator.Add(1, ref result, 2);
            //Console.WriteLine("x + y = {2} when x = {0} and y = {1}", 1, 2, result);

            ICalculator calculator = SerivceProxyFactory<ICalculator>.Create(MessageVersion.Default, new Uri("http://localhost/Artech.WcfFrameworkSimulator/Calculator.aspx"));
            double result = calculator.Add(1, 2);
            Console.WriteLine("x + y = {2} when x = {0} and y = {1}", 1, 2, result);
        }
    }
}