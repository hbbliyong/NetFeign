﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Reflection;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Remoting.Proxies;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;
using System.Xml;
namespace Artech.WcfFrameworkSimulator.Client
{
    public class ServiceRealProxy<IContract> : RealProxy
    {
        private Uri _remoteAddress;
        private IDictionary<string, IClientMessageFormatter> _messageFormatters;
        private MessageVersion _messageVersion = MessageVersion.Default;
        private MessageEncoderFactory _messageEncoderFactory;       

        public ServiceRealProxy(MessageVersion messageVersion, Uri address, IDictionary<string, IClientMessageFormatter> messageFormaters, MessageEncoderFactory messageEncoderFactory)
            : base(typeof(IContract))
        {
            object[] attribute = typeof(IContract).GetCustomAttributes(typeof(ServiceContractAttribute), false);
            if (attribute.Length == 0)
            {
                throw new InvalidOperationException(string.Format("The type \"{0}\" is not a ServiceContract!", typeof(IContract).AssemblyQualifiedName));
            }
            this._messageVersion = messageVersion;
            this._remoteAddress = address;
            this._messageFormatters = messageFormaters;
            this._messageEncoderFactory = messageEncoderFactory;
        }

        public override IMessage Invoke(IMessage msg)
        {
            IMethodCallMessage methodCall = (IMethodCallMessage)msg;
            
            //Get Operation name.
            object[] attributes = methodCall.MethodBase.GetCustomAttributes(typeof(OperationContractAttribute), true);
            if (attributes.Length == 0)
            {
                throw new InvalidOperationException(string.Format("The method \"{0}\" is not a valid OperationContract.", methodCall.MethodName));
            }
            OperationContractAttribute attribute = (OperationContractAttribute)attributes[0];
            string operationName = string.IsNullOrEmpty(attribute.Name) ? methodCall.MethodName : attribute.Name;
            
            //序列化请求消息
            Message requestMessage = this._messageFormatters[operationName].SerializeRequest(this._messageVersion, methodCall.InArgs);

            //添加必要的WS-Address报头
            EndpointAddress address = new EndpointAddress(this._remoteAddress);
            requestMessage.Headers.MessageId = new UniqueId(Guid.NewGuid());
            requestMessage.Headers.ReplyTo = new EndpointAddress("http://www.w3.org/2005/08/addressing/anonymous");
            address.ApplyTo(requestMessage);

            //对请求消息进行编码，并将编码生成的字节发送通过HttpWebRequest向服务端发送
            HttpWebRequest webRequest = (HttpWebRequest)HttpWebRequest.Create(this._remoteAddress);
            webRequest.Method = "Post";
            webRequest.KeepAlive = true;
            webRequest.ContentType = "application/soap+xml; charset=utf-8";
            ArraySegment<byte> bytes = this._messageEncoderFactory.Encoder.WriteMessage(requestMessage, int.MaxValue, BufferManager.CreateBufferManager(long.MaxValue, int.MaxValue));
            webRequest.ContentLength = bytes.Array.Length;
            webRequest.GetRequestStream().Write(bytes.Array, 0, bytes.Array.Length);
            webRequest.GetRequestStream().Close();
            WebResponse webResponse = webRequest.GetResponse();

            //对HttpResponse进行解码生成回复消息.
            Message responseMessage = this._messageEncoderFactory.Encoder.ReadMessage(webResponse.GetResponseStream(), int.MaxValue);
            
            //回复消息进行反列化生成相应的对象，并映射为方法调用的返回值或者ref/out参数
            object[] allArgs = (object[])Array.CreateInstance(typeof(object), methodCall.ArgCount);
            Array.Copy(methodCall.Args, allArgs, methodCall.ArgCount);
            object[] refOutParameters = new object[GetRefOutParameterCount(methodCall.MethodBase)];            
            object returnValue = this._messageFormatters[operationName].DeserializeReply(responseMessage, refOutParameters);
            MapRefOutParameter(methodCall.MethodBase, allArgs, refOutParameters);

            //通过ReturnMessage的形式将返回值和ref/out参数返回
            return new ReturnMessage(returnValue, allArgs, allArgs.Length, methodCall.LogicalCallContext, methodCall);
        }

        private int GetRefOutParameterCount(MethodBase method)
        {
            int count = 0;
            foreach (ParameterInfo parameter in method.GetParameters())
            {
                if (parameter.IsOut || parameter.ParameterType.IsByRef)
                {
                    count++;
                }
            }
            return count;
        }

        private void MapRefOutParameter(MethodBase method, object[] allArgs, object[] refOutArgs)
        {
            List<int> refOutParamPositionsList = new List<int>();
            foreach (ParameterInfo parameter in method.GetParameters())
            {
                if (parameter.IsOut || parameter.ParameterType.IsByRef)
                {
                    refOutParamPositionsList.Add(parameter.Position);
                }
            }
            int[] refOutParamPositionArray = refOutParamPositionsList.ToArray();
            for (int i = 0; i < refOutArgs.Length; i++)
            {
                allArgs[refOutParamPositionArray[i]] = refOutArgs[i];
            }
        }
    }
}