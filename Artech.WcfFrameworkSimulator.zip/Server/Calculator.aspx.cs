﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;
using System.Text;
using Artech.WcfFrameworkSimulator.Contracts;

public partial class Calculator : System.Web.UI.Page
{
    private static MessageVersion messageversion = MessageVersion.Default;
    private static MessageEncoderFactory encoderFactory;
    private static IDictionary<string, IDispatchMessageFormatter> dispatchFormatters;
    private static IDictionary<string, IOperationInvoker> operationInvokers;
    private static IDictionary<string, MethodInfo> methods;

    protected Calculator()
    {
        IDictionary<string, IClientMessageFormatter> clientFormatters;
        Utility.Create<ICalculator>(out encoderFactory, out clientFormatters, out dispatchFormatters, out operationInvokers, out methods);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //对HttpPRequest进行解码生成请求消息对象
        Message request = encoderFactory.Encoder.ReadMessage(this.Request.InputStream, int.MaxValue, "application/soap+xml; charset=utf-8"); 
        
        //通过请求消息得到代表服务操作的Action
        string action = request.Headers.Action;

        //通过Action从MethodInfo字典中获取服务操作对应的MethodInfo对象
        MethodInfo method = methods[action];

        //得到输出参数的数量
        int outArgsCount = 0;
        foreach (var parameter in method.GetParameters())
        {
            if (parameter.IsOut)
            {
                outArgsCount++;
            }
        }

        //创建数组容器，用于保存请求消息反序列后生成的输入参数对象
        int inputArgsCount = method.GetParameters().Length-outArgsCount;
        object[] parameters = new object[inputArgsCount];
        
        try
        {
            dispatchFormatters[action].DeserializeRequest(request, parameters);
        }
        catch
        {
        
        }

        List<object> inputArgs = new List<object>();        
        object[] outArgs = new object[outArgsCount];
        //创建服务对象，在WCF中服务对象通过InstanceProvider创建
        object serviceInstance = Activator.CreateInstance(typeof(CalculatorService));
        //执行服务操作
        object result = operationInvokers[action].Invoke(serviceInstance, parameters, out outArgs);
        //将操作执行的结果（返回值或者输出参数）序列化生成回复消息
        Message reply = dispatchFormatters[action].SerializeReply(messageversion, outArgs, result);
        this.Response.ClearContent();
        this.Response.ContentEncoding = Encoding.UTF8;
        this.Response.ContentType = "application/soap+xml; charset=utf-8";
        //对回复消息进行编码，并将编码后的消息通过HttpResponse返回
        encoderFactory.Encoder.WriteMessage(reply, this.Response.OutputStream);
        this.Response.Flush();
    }
}

public class CalculatorService : ICalculator
{

    #region ICalculator Members

    public double Add(double x, double y)
    {
        return x + y;
    }

    #endregion
}
